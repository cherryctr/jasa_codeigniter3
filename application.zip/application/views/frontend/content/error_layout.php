<section class="cs main_color8 section_404 section_padding_top_150 section_padding_bottom_150">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="not_found highlight"> <span>404</span> </p>
							<h1>Oops, page not found!</h1>
							<p>Back To :</p>
							<p> <a href="<?php echo base_url(); ?>katalog" class="theme_button color1">katalog page</a> </p>
							<p> or </p>
							<p> <a href="<?php echo base_url(); ?>" class="theme_button color1">home page</a> </p>
						</div>
					</div>
				</div>
			</section>
			<section class="page_copyright cs section_padding_top_110 section_padding_bottom_100">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-center">
							<p class="page_social bottommargin_20"> <a href="#" class="social-icon light-bg-icon color-icon rounded-icon socicon-facebook"></a> <a href="#" class="social-icon light-bg-icon color-icon rounded-icon socicon-twitter"></a> <a href="#" class="social-icon light-bg-icon color-icon rounded-icon socicon-googleplus"></a>								</p>
							<p class="small-text black">&copy; Copyright 2018 All Rights Reserved</p>
						</div>
					</div>
				</div>
			</section>